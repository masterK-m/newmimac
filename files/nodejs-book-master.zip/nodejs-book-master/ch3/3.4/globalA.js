module.exports = () => global.message;
